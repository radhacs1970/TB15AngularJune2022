import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';
import { Employee } from '../employee';

@Component({
  selector: 'app-emplist',
  templateUrl: './emplist.component.html',
  styleUrls: ['./emplist.component.css']
})
export class EmplistComponent implements OnInit {
  employees: Employee[];
  nestedjson: any;

  constructor(private emplistServ: EmployeeService) { }

  ngOnInit(): void {
    this.employees = this.emplistServ.getAllEmployees();
    console.log(this.employees);
    this.nestedjson = {  'name': 'Arvind',
                        'age': 25,
                        'Address' : {
                            'no': 12,
                            'city': 'Delhi',
                            'Country': 'India'
                      }};
  }

}
