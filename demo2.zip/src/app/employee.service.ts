import { Injectable } from '@angular/core';
import { Employee } from './employee';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
  employees: Employee[];
  constructor() { 

    this.employees = [
      new Employee( 'emp101', 'Tom',  'Male',
           5500, '05/14/1998'),
      new Employee( 'emp102', 'John',  'Male',
           6000, '06/12/1999'),
      new Employee( 'emp103', 'Peter',  'Male',
           8000, '05/24/2000'),
      new Employee( 'emp104', 'Mary',  'Female',
           9000, '07/04/1999'),
      new Employee( 'emp105', 'Lucy',  'Female',
           3000, '08/09/1998'),
      new Employee( 'emp106', 'Abram',  'Female',
           3000, '08/09/1992'),
      new Employee('emp107', 'mahi', 'Female', 8909, '02/10/2000')
    ];
  }

  getAllEmployees(): Employee[] {
    return this.employees;
  }

  getEmployeeByCode( empcode: string): Employee{
       console.log( ' getempcode ' + empcode);
     for (let emp of this.employees) {
          let cd = emp.code;
          if (cd == empcode) {
            return emp;
          }
        }
     return null;
   }
}
