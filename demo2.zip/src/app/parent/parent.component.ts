import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-parent',
  templateUrl: './parent.component.html',
  styleUrls: ['./parent.component.css']
})
export class ParentComponent implements OnInit {
  pmsgToChild: string;

  msgFromchild: string;
  
  constructor() { }

  ngOnInit(): void {
    this.pmsgToChild = 'haha';
  }
  buttonClickOnChildComponent( argMsgFromchild: string ): void {
    this.msgFromchild = argMsgFromchild;
  }
}
