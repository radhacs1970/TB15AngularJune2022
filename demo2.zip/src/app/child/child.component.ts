import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent implements OnInit {
  @Input()
  msgRecvFromParent: string;

  @Output()
  bclick: EventEmitter<string> = new EventEmitter<string>();
  count = 0;

  constructor() { }

  ngOnInit(): void {
  }
  
  buttonclicked(){
    this.count++;
    this.bclick.emit('button is clicked in child ' + this.count);
  }
}
