export class Employee {

  constructor(
    public code: string,
    public name: string,
    public gender: string,
    public annualSalary: number,
    public dateOfBirth: string
  ){
  }
}
