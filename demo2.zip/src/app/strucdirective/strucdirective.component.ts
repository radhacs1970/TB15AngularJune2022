import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-strucdirective',
  templateUrl: './strucdirective.component.html',
  styleUrls: ['./strucdirective.component.css']
})
export class StrucdirectiveComponent implements OnInit {

  apps = ['WhatsApp', 'Instagram', 'Facebook'];
  showMe: boolean;
  num: number;
  constructor() { }

  ngOnInit(): void {
    this.apps.push('gmail');
    this.apps.push('candy crush');
    this.showMe = true;
  }


}
