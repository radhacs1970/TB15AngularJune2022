import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { HomeComponent } from './home/home.component';
import { DatabindComponent } from './databind/databind.component';
import { EmplistComponent } from './emplist/emplist.component';
import { EmpdetailComponent } from './empdetail/empdetail.component';
import { ReactformComponent } from './reactform/reactform.component';

const routes: Routes = [
  {path: 'home', component: HomeComponent },
  {path: 'databind', component: DatabindComponent},
  {path: 'emplist', component: EmplistComponent},
  {path: 'reactform', component: ReactformComponent },
  {path: 'emplist/:empId', component: EmpdetailComponent},
 
  { path: '**', redirectTo: 'home', pathMatch: 'full' },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
