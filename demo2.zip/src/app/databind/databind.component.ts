import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-databind',
  templateUrl: './databind.component.html',
  styleUrls: ['./databind.component.css']
})
export class DatabindComponent implements OnInit {
  mystring: string;
  mynum: number;
  propEmpName: string;
  toggleb: boolean;
  imgUrl = 'assets/img1.jpg';
  fname: string;

  constructor() {
    this.mynum = 10 + 8;
    this.mystring = 'green 76';
    this.propEmpName = 'Megha';
    this.toggleb = false;
    this.fname = "pooja";
   }

  ngOnInit(): void {
    this.fname = "Surya Devi";
  }
  myalert(value: string): void{
    alert(value + ' add whatever u need ');
    console.log( ' event binding ' + value );
    this.propEmpName = 'kalpana';
  }
  onButtonclick(): void{
    this.toggleb = !this.toggleb;
  }
}
