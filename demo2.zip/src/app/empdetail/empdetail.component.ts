import { Component, OnInit } from '@angular/core';
import { Employee } from '../employee';
import { ActivatedRoute, Router } from '@angular/router';

import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-empdetail',
  templateUrl: './empdetail.component.html',
  styleUrls: ['./empdetail.component.css']
})
export class EmpdetailComponent implements OnInit {
  employee: Employee;
  empCode: string;
 

  constructor( 
    private _activatedRoute: ActivatedRoute,
    private _empServ: EmployeeService,
    private router: Router) { }

  ngOnInit(): void {

    this.empCode =
      this._activatedRoute.snapshot.params['empId'];
    console.log(' from snapshot ' + this.empCode);
    this.employee = this._empServ.getEmployeeByCode( this.empCode);

  }

  gotoEmplist(): void{
    this.router.navigate(['/emplist']);
  }

}
