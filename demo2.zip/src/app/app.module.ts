import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule} from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { DatabindComponent } from './databind/databind.component';
import { StrucdirectiveComponent } from './strucdirective/strucdirective.component';
import { HighlightDirective } from './highlight.directive';
import { NgclassngstyleComponent } from './ngclassngstyle/ngclassngstyle.component';
import { EmplistComponent } from './emplist/emplist.component';
import { EmptitlePipe } from './emptitle.pipe';
import { ParentComponent } from './parent/parent.component';
import { ChildComponent } from './child/child.component';
import { HomeComponent } from './home/home.component';
import { EmpdetailComponent } from './empdetail/empdetail.component';
import { ReactformComponent } from './reactform/reactform.component';

@NgModule({
  declarations: [
    AppComponent,
    DatabindComponent,
    StrucdirectiveComponent,
    HighlightDirective,
    NgclassngstyleComponent,
    EmplistComponent,
    EmptitlePipe,
    ParentComponent,
    ChildComponent,
    HomeComponent,
    EmpdetailComponent,
    ReactformComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
