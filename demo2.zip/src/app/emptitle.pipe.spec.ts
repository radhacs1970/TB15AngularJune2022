import { EmptitlePipe } from './emptitle.pipe';

describe('EmptitlePipe', () => {
  it('create an instance', () => {
    const pipe = new EmptitlePipe();
    expect(pipe).toBeTruthy();
  });
});
